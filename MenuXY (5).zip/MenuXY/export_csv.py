import sqlite3
import csv


def read_data_from_sqlite(database_file, table_name, csv_file):
    # Connect to the SQLite database
    conn = sqlite3.connect(database_file)
    cursor = conn.cursor()

    # Fetch data from the table
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()

    with open(csv_file, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([i[0] for i in cursor.description])  # Write column headers
        writer.writerows(rows)

    print(f"Data successfully exported to {csv_file}")

    # Close the database connection
    conn.close()


def export_data():
    database_file = 'myDatabase.db'
    table_name = 'business'
    csv_file = 'business.csv'

    # Read data from SQLite database
    data = read_data_from_sqlite(database_file, table_name, csv_file)



