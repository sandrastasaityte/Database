import sqlite3


def sp_execute(sql_command):
    # Connect to SQLite database
    conn = sqlite3.connect('myDatabase.db')

    # Create a cursor object
    cursor = conn.cursor()
    cursor.execute(sql_command)

    # Commit changes and close connection
    conn.commit()
    conn.close()


def sp_query(sql_command):
    # Connect to SQLite database
    conn = sqlite3.connect('myDatabase.db')

    # Create a cursor object
    cursor = conn.cursor()
    cursor.execute(sql_command)
    rows = cursor.fetchall()

    # Display fetched data
    for row in rows:
        print(row)

    # Commit changes and close connection
    conn.commit()
    conn.close()


def create_table(table_name, columns_definition):
    sql_command = f'CREATE TABLE IF NOT EXISTS {table_name} ( {columns_definition} )'
    sp_execute(sql_command)


def drop_table(table_name):
    sql_command = f'DROP TABLE IF EXISTS {table_name}'
    sp_execute(sql_command)


def insert_record(table_name, columns_definition, record_values):
    sql_command = f'INSERT INTO {table_name} ( {columns_definition} ) VALUES ( {record_values} )'
    sp_execute(sql_command)


def delete_record(table_name, columns_definition, record_values):
    sql_command = f"DELETE FROM {table_name} WHERE {columns_definition} = '{record_values}'"
    print(f'{sql_command =}"')
    sp_execute(sql_command)


def update_record(table_name, column_definition, record_value, primary_key_name, primary_key_value):
    sql_command = (
                   f" UPDATE {table_name} SET {column_definition} = {record_value} "
                   f" WHERE {primary_key_name} = '{primary_key_value}' "
                   )

    sp_execute(sql_command)


def select_record(table_name, columns_definition, record_values):
    sql_command = f"SELECT * FROM {table_name} WHERE {columns_definition} = '{record_values}'"
    sp_query(sql_command)


def select_all(table_name):
    sql_command = f"SELECT * FROM {table_name}"
    sp_query(sql_command)
