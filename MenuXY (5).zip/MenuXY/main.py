from menu_xy import (show_menu,
                     select_option,
                     )

from business import (business_create_table,
                      set_business_record_values,
                      set_update_record,
                      set_delete_record,
                      get_select_record,
                      business_drop_table,
                      get_select_all
                      )

from export_csv import export_data
from import_csv import read_business_csv

from graphics import plot_graphic


def main():
    show_menu()
    number_of_selections = 0
    while True:
        selected_option = select_option()
        print(f' The option is: {selected_option =}')
        number_of_selections += 1
        if number_of_selections > 3:
            show_menu()
            number_of_selections = 0

        if selected_option == 0:
            print('Good bye!')
            break
        else:
            run_selected_option(selected_option)


def run_selected_option(selected_option):
    try:
        if int(selected_option) == 1:
            business_create_table()

        if int(selected_option) == 2:
            business_drop_table()

        if int(selected_option) == 3:
            set_business_record_values()

        if int(selected_option) == 4:
            set_update_record()

        if int(selected_option) == 5:
            set_delete_record()

        if int(selected_option) == 6:
            get_select_record()

        if int(selected_option) == 7:
            export_data()

        if int(selected_option) == 8:
            plot_graphic()

        if int(selected_option) == 9:
            read_business_csv()

        if int(selected_option) == 10:
            get_select_all()

    except:
        print('Error:')


if __name__ == '__main__':
    main()
