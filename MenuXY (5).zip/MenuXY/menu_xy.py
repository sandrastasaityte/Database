def show_menu():
    print("============================")
    print("===      M E N U         ===")
    print("===----------------------===")
    print("=== 1)  Create Table     ===")
    print("=== 2)  Drop Table       ===")
    print("=== 3)  Insert record    ===")
    print("=== 4)  Update record    ===")
    print("=== 5)  Delete record    ===")
    print("=== 6)  Find record      ===")
    print("=== 7)  Export records   ===")
    print("=== 8)  Plot Graphic     ===")
    print("=== 9)  Import CSV       ===")
    print("=== 10) Show all records ===")
    print("=== 0)  EXIT             ===")
    print("============================")


def select_option():
    try:
        sel_option = int(input('Select your option: '))
    except ValueError:
        print('Invalid option, please try again.')
    else:
        return sel_option
